# Kasir Material (Android)

Aplikasi Android offline untuk toko material bangunan.

Fitur:
- Data barang: nama, satuan, modal, harga jual, stok
- Edit dan hapus barang
- Stok masuk
- Penjualan mengurangi stok otomatis dan menolak jumlah melebihi stok
- Hitung omzet, modal penjualan, dan keuntungan kotor
- Ringkasan nilai stok dan barang stok menipis
- Riwayat transaksi
- Data disimpan lokal di SharedPreferences, tanpa internet/server

## Membuat APK
1. Buka proyek ini di Android Studio (versi yang mendukung Android Gradle Plugin 8.7.3).
2. Tunggu Gradle sync selesai.
3. Pilih **Build > Build APK(s)**.
4. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

Aplikasi ini merupakan versi awal yang bisa dikembangkan. Uji terlebih dahulu dan backup data penting sebelum penggunaan nyata.
