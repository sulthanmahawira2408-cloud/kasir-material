package com.example.kasirmaterial;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import org.json.*;
import java.text.NumberFormat;
import java.util.*;

public class MainActivity extends Activity {
    final String PREF = "kasir_material_data";
    ArrayList<Item> items = new ArrayList<>();
    ArrayList<String> history = new ArrayList<>();
    LinearLayout root, content, nav;
    String page = "Beranda";
    final int green = Color.rgb(23,107,82), dark = Color.rgb(16,77,61), bg = Color.rgb(245,247,246);
    NumberFormat rupiah = NumberFormat.getCurrencyInstance(new Locale("id","ID"));

    static class Item {
        String id, name, unit;
        double cost, price, stock;
        Item(String id, String name, String unit, double cost, double price, double stock) {
            this.id=id; this.name=name; this.unit=unit; this.cost=cost; this.price=price; this.stock=stock;
        }
    }

    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(dark); getWindow().setNavigationBarColor(dark); load(); render(); }

    String money(double n) { return rupiah.format(n).replace(",00",""); }
    void save() {
        try {
            JSONArray a = new JSONArray();
            for(Item i:items) { JSONObject o=new JSONObject(); o.put("id",i.id);o.put("name",i.name);o.put("unit",i.unit);o.put("cost",i.cost);o.put("price",i.price);o.put("stock",i.stock);a.put(o); }
            JSONArray h=new JSONArray(); for(String s:history) h.put(s);
            getSharedPreferences(PREF,0).edit().putString("items",a.toString()).putString("history",h.toString()).apply();
        } catch(Exception e) {}
    }
    void load() {
        try {
            String s=getSharedPreferences(PREF,0).getString("items","[]"); JSONArray a=new JSONArray(s);
            for(int x=0;x<a.length();x++){JSONObject o=a.getJSONObject(x);items.add(new Item(o.getString("id"),o.getString("name"),o.getString("unit"),o.getDouble("cost"),o.getDouble("price"),o.getDouble("stock")));}
            JSONArray h=new JSONArray(getSharedPreferences(PREF,0).getString("history","[]"));for(int x=0;x<h.length();x++)history.add(h.getString(x));
        }catch(Exception e){}
    }
    TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,4,0,4);return t;
    }
    LinearLayout column() { LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l; }
    LinearLayout row() { LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l; }
    void pad(View v,int n) { v.setPadding(n,n,n,n); }
    LinearLayout.LayoutParams lp(int w,int h) { return new LinearLayout.LayoutParams(w,h); }
    TextView button(String s,Runnable r) {
        TextView b=text(s,14,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setBackgroundColor(green);b.setPadding(16,13,16,13);
        b.setOnClickListener(v->r.run());return b;
    }
    void card(LinearLayout parent, View child) {
        LinearLayout box=column();box.setBackgroundColor(Color.WHITE);box.setPadding(16,12,16,12);
        box.addView(child);LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(0,0,0,12);parent.addView(box,p);
    }
    EditText field(String hint, boolean numeric) {
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setHint(hint);
        if(numeric)e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(12,8,12,8);return e;
    }
    void render() {
        root=column();root.setBackgroundColor(bg);setContentView(root);
        LinearLayout header=column();header.setBackgroundColor(dark);header.setPadding(18,15,18,15);
        header.addView(text("KASIR MATERIAL",20,Color.WHITE,true));
        header.addView(text("Kelola stok • penjualan • keuntungan",12,Color.rgb(210,235,226),false));
        root.addView(header);
        content=column();content.setPadding(16,16,16,16);
        ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setBackgroundColor(Color.WHITE);
        String[] tabs={"Beranda","Barang","Jual","Riwayat"};
        for(String t:tabs){TextView b=text(t,12,t.equals(page)?green:Color.DKGRAY,true);b.setGravity(Gravity.CENTER);b.setPadding(4,16,4,16);nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->{page=t;render();});}
        root.addView(nav);
        if(page.equals("Beranda")) home(); else if(page.equals("Barang")) products(); else if(page.equals("Jual")) sellPage(); else historyPage();
    }
    void home() {
        content.addView(text("Ringkasan usaha",21,Color.BLACK,true));
        double capital=0,value=0;int low=0;for(Item i:items){capital+=i.cost*i.stock;value+=i.price*i.stock;if(i.stock<=5)low++;}
        metric("Jenis barang",String.valueOf(items.size()),"Total modal stok",money(capital));
        metric("Nilai stok harga jual",money(value),"Stok menipis (≤ 5)",String.valueOf(low));
        content.addView(text("Aksi cepat",17,Color.BLACK,true));
        LinearLayout r=row();r.addView(button("+ Tambah barang",()->addItemDialog()),new LinearLayout.LayoutParams(0,-2,1));
        TextView gap=text(" ",12,0,false);r.addView(gap,lp(8,1));r.addView(button("Catat penjualan",()->{page="Jual";render();}),new LinearLayout.LayoutParams(0,-2,1));content.addView(r);
        content.addView(text("Barang terbaru",17,Color.BLACK,true));
        if(items.isEmpty()) content.addView(text("Belum ada barang. Tekan Tambah barang untuk mulai.",14,Color.GRAY,false));
        for(int x=Math.max(0,items.size()-4);x<items.size();x++) itemCard(items.get(x),false);
    }
    void metric(String a,String b,String c,String d) {
        LinearLayout r=row();LinearLayout left=column(),right=column();left.addView(text(a,12,Color.GRAY,false));left.addView(text(b,17,green,true));right.addView(text(c,12,Color.GRAY,false));right.addView(text(d,17,Color.BLACK,true));
        r.addView(left,new LinearLayout.LayoutParams(0,-2,1));r.addView(right,new LinearLayout.LayoutParams(0,-2,1));card(content,r);
    }
    void products() {
        LinearLayout title=row();title.addView(text("Daftar barang",21,Color.BLACK,true),new LinearLayout.LayoutParams(0,-2,1));title.addView(button("+ Tambah",()->addItemDialog()));content.addView(title);
        if(items.isEmpty())content.addView(text("Belum ada barang yang disimpan.",14,Color.GRAY,false));
        for(Item i:new ArrayList<>(items))itemCard(i,true);
    }
    void itemCard(Item i,boolean actions) {
        LinearLayout box=column();box.addView(text(i.name,17,Color.BLACK,true));
        box.addView(text("Kode: "+i.id+"  •  Satuan: "+i.unit,12,Color.GRAY,false));
        box.addView(text("Modal "+money(i.cost)+"   |   Jual "+money(i.price),14,Color.DKGRAY,false));
        box.addView(text("Stok: "+fmt(i.stock)+" "+i.unit+"   •   Untung/unit: "+money(i.price-i.cost),14,i.stock<=5?Color.rgb(180,75,0):green,true));
        if(actions) {
            LinearLayout r=row();r.addView(button("Edit",()->editItemDialog(i)),new LinearLayout.LayoutParams(0,-2,1));
            TextView sp=text("",10,0,false);r.addView(sp,lp(8,1));
            r.addView(button("Stok masuk",()->stockInDialog(i)),new LinearLayout.LayoutParams(0,-2,1));
            TextView sp2=text("",10,0,false);r.addView(sp2,lp(8,1));
            r.addView(button("Hapus",()->deleteItem(i)),new LinearLayout.LayoutParams(0,-2,1));box.addView(r);
        }
        card(content,box);
    }
    String fmt(double n){ if(n==(long)n)return String.valueOf((long)n);return String.valueOf(n); }
    void addItemDialog(){ itemForm(null); }
    void editItemDialog(Item i){itemForm(i);}
    void itemForm(Item old) {
        LinearLayout form=column();form.setPadding(8,0,8,0);
        EditText name=field("Nama barang (contoh: Semen Tiga Roda)",false);
        EditText unit=field("Satuan (sak, batang, kg, meter, m³, buah)",false);
        EditText cost=field("Modal per satuan (Rp)",true),price=field("Harga jual per satuan (Rp)",true),stock=field("Jumlah stok",true);
        if(old!=null){name.setText(old.name);unit.setText(old.unit);cost.setText(fmt(old.cost));price.setText(fmt(old.price));stock.setText(fmt(old.stock));}
        form.addView(name);form.addView(unit);form.addView(cost);form.addView(price);form.addView(stock);
        new AlertDialog.Builder(this).setTitle(old==null?"Tambah barang":"Edit barang").setView(form)
        .setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            try{
                String n=name.getText().toString().trim(),u=unit.getText().toString().trim();
                double c=Double.parseDouble(cost.getText().toString()),p=Double.parseDouble(price.getText().toString()),s=Double.parseDouble(stock.getText().toString());
                if(n.isEmpty()||u.isEmpty()||c<0||p<0||s<0)throw new Exception();
                if(old==null)items.add(new Item("BRG"+(System.currentTimeMillis()%1000000),n,u,c,p,s));
                else{old.name=n;old.unit=u;old.cost=c;old.price=p;old.stock=s;}
                save();render();toast("Data barang tersimpan");
            }catch(Exception e){toast("Periksa isian. Angka harus valid dan tidak boleh negatif.");}
        }).show();
    }
    void stockInDialog(Item i) {
        EditText qty=field("Jumlah barang masuk ("+i.unit+")",true);
        EditText note=field("Catatan (opsional)",false);LinearLayout f=column();f.addView(qty);f.addView(note);
        new AlertDialog.Builder(this).setTitle("Tambah stok: "+i.name).setView(f).setNegativeButton("Batal",null).setPositiveButton("Simpan",(d,w)->{
            try{double q=Double.parseDouble(qty.getText().toString());if(q<=0)throw new Exception();i.stock+=q;history.add(now()+" • STOK MASUK • "+i.name+" • "+fmt(q)+" "+i.unit+(note.getText().length()>0?" • "+note.getText():""));save();render();toast("Stok berhasil ditambah");}
            catch(Exception e){toast("Masukkan jumlah lebih dari nol");}
        }).show();
    }
    void deleteItem(Item i) {
        new AlertDialog.Builder(this).setTitle("Hapus barang?").setMessage("Data "+i.name+" akan dihapus dari daftar.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{items.remove(i);save();render();}).show();
    }
    void sellPage() {
        content.addView(text("Catat penjualan",21,Color.BLACK,true));
        if(items.isEmpty()){content.addView(text("Tambahkan barang terlebih dahulu di menu Barang.",14,Color.GRAY,false));content.addView(button("Ke daftar barang",()->{page="Barang";render();}));return;}
        Spinner sp=new Spinner(this);ArrayList<String> labels=new ArrayList<>();for(Item i:items)labels.add(i.name+" • stok "+fmt(i.stock)+" "+i.unit+" • "+money(i.price));
        sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));content.addView(text("Pilih barang",14,Color.DKGRAY,true));content.addView(sp,lp(-1,-2));
        EditText qty=field("Jumlah terjual",true);content.addView(qty);
        EditText actual=field("Harga jual per satuan (kosongkan = harga default)",true);content.addView(actual);
        TextView preview=text("Pilih barang dan masukkan jumlah untuk menghitung total.",14,Color.GRAY,false);content.addView(preview);
        Runnable calc=()->{try{Item i=items.get(sp.getSelectedItemPosition());double q=Double.parseDouble(qty.getText().toString());String z=actual.getText().toString().trim();double p=z.isEmpty()?i.price:Double.parseDouble(z);preview.setText("Total: "+money(q*p)+"  •  Perkiraan untung: "+money(q*(p-i.cost)));}catch(Exception e){preview.setText("Masukkan jumlah terjual.");}};
        qty.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){calc.run();}public void afterTextChanged(android.text.Editable e){}});
        actual.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){calc.run();}public void afterTextChanged(android.text.Editable e){}});
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){calc.run();}});
        content.addView(text("Stok akan otomatis berkurang setelah transaksi disimpan.",12,Color.GRAY,false));
        content.addView(button("Simpan penjualan",()->{
            try{
                Item i=items.get(sp.getSelectedItemPosition());double q=Double.parseDouble(qty.getText().toString());String z=actual.getText().toString().trim();double p=z.isEmpty()?i.price:Double.parseDouble(z);
                if(q<=0||p<0)throw new Exception();if(q>i.stock){toast("Stok tidak cukup. Stok tersedia: "+fmt(i.stock));return;}
                double total=q*p,profit=q*(p-i.cost);i.stock-=q;
                history.add(0,now()+" • TERJUAL • "+i.name+" • "+fmt(q)+" "+i.unit+" • Omzet "+money(total)+" • Untung "+money(profit));
                save();new AlertDialog.Builder(this).setTitle("Penjualan tersimpan").setMessage("Barang: "+i.name+"\nJumlah: "+fmt(q)+" "+i.unit+"\nOmzet: "+money(total)+"\nModal: "+money(q*i.cost)+"\nKeuntungan kotor: "+money(profit)+"\nSisa stok: "+fmt(i.stock)+" "+i.unit).setPositiveButton("OK",(d,w)->{page="Beranda";render();}).show();
            }catch(Exception e){toast("Masukkan jumlah dan harga yang valid.");}
        }));
    }
    void historyPage() {
        content.addView(text("Riwayat transaksi",21,Color.BLACK,true));
        if(history.isEmpty())content.addView(text("Belum ada transaksi.",14,Color.GRAY,false));
        for(String s:history){LinearLayout b=column();b.addView(text(s,14,Color.DKGRAY,false));card(content,b);}
        if(!history.isEmpty())content.addView(button("Hapus riwayat",()->new AlertDialog.Builder(this).setTitle("Hapus riwayat?").setMessage("Riwayat transaksi akan dihapus. Data stok tidak berubah.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{history.clear();save();render();}).show()));
    }
    String now(){return new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",new Locale("id","ID")).format(new Date());}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
